import{c as ae,a as ne,b as se,d as re,e as le,f as ie,h as oe,g as ce,i as de,s as Z,j as Q,k as v,l as q,m as ee,n as pe,o as A,p as ue,q as he,r as te,t as ge,u as me,v as L,w as H,x as o,y as fe,z as be,A as ve,B as ye,C as ke,D as we}from"../../thumb.js";function Se(e,a,n,r){var x;const t=a[e.appid],l=(t==null?void 0:t.peak)??0,d=(t==null?void 0:t.current)??null,g=ae(n),h=(t==null?void 0:t.localAllTimePeak)??0,s=Math.max((t==null?void 0:t.allTimePeak)??0,l,h,g??0),k=s>0?s:null,p=(t==null?void 0:t.peak24h)??null,y=ne(n),w=se(n),u=re(n,r),m=le(n,r),S=ie(r).filter(E=>oe(n,E.windowMs)),P=((x=S[0])==null?void 0:x.key)??null,b=ce(n),f=(b==null?void 0:b.level.cls)??"stable",$=de(n),T=$e(b,$),c=Z(n),i=Q(n);return{game:e,current:d,peak24h:p,allTimePeak:k,...t!=null&&t.allTimePeakLabel?{allTimePeakLabel:t.allTimePeakLabel}:{},displayTrendPct:T.pct,displayTrendIcon:T.icon,displayTrendCls:T.cls,...y!=null?{avg24h:y}:{},...w!=null?{gain24h:w}:{},...u!=null?{retentionAvg:u}:{},...m!=null?{retentionGain:m}:{},retentionDays:r,availableGraphWindows:S,defaultGraphWindow:P,trend:b,trendCls:f,latestChangePct:$,snaps:n,sparklineStroke:c,svgStr:i,fetchedAt:(t==null?void 0:t.fetchedAt)??0,...(t==null?void 0:t.twitchViewers)!=null?{twitchViewers:t.twitchViewers}:{},...(t==null?void 0:t.discountPct)!=null?{discountPct:t.discountPct}:{},...t!=null&&t.priceFormatted?{priceFormatted:t.priceFormatted}:{},...t!=null&&t.priceOriginalFormatted?{priceOriginalFormatted:t.priceOriginalFormatted}:{}}}function $e(e,a){return e?{pct:e.pct,icon:e.level.icon,cls:e.level.cls}:a!=null?{pct:a,icon:"↕",cls:Te(a)}:{pct:null,icon:null,cls:"stable"}}function Te(e){return e>=8?"strong-up":e>=2?"up":e<=-8?"strong-down":e<=-2?"down":"stable"}async function Ce(e,a,n,r){return Promise.all(e.map(async t=>{let l=[];try{l=await n(t.appid)}catch{}return Se(t,a,l,r)}))}function Pe(e){const{game:a,current:n,peak24h:r,allTimePeak:t,allTimePeakLabel:l,trend:d,latestChangePct:g,fetchedAt:h}=e,s="─".repeat(32),k=a.name,p=[];if(p.push(`🎮 ${k} — SteamWatch`),p.push(s),p.push(`👥 Current:  ${v(n)}`),d&&p.push(`${d.level.icon} Trend:    ${q(d.pct)} (${d.level.label})`),g!=null&&p.push(`↕ Latest change: ${q(g)}`),r||t){const y=r?`24h peak: ${v(r)}`:"",w=t?`All-time peak: ${v(t)}${l?` (${l})`:""}`:"",u=[y,w].filter(Boolean).join("  ·  ");p.push(`📊 ${u}`)}return h>0&&p.push(`🕐 Updated: ${ee(h)}`),p.push(s),p.push(`steamdb.info/app/${a.appid}`),p.push("SteamWatch by TREVISOFT · github.com/trevonerd"),p.join(`
`)}const B=440,R=128;async function xe(e){const{game:a,current:n,peak24h:r,allTimePeak:t,trend:l,snaps:d,sparklineStroke:g}=e,h=document.createElement("canvas");h.width=B,h.height=R;const s=h.getContext("2d");s.fillStyle="#080c15",s.fillRect(0,0,B,R),s.fillStyle=Le(e.trendCls),s.fillRect(0,0,3,R);const k=12,p=18,y=60,w=44;try{const $=await Ee(a.image);s.save(),O(s,k,p,y,w,4),s.clip(),s.drawImage($,k,p,y,w),s.restore()}catch{s.fillStyle="#131f35",O(s,k,p,y,w,4),s.fill()}const u=k+y+12;s.fillStyle="#dde4ee",s.font="bold 15px system-ui, -apple-system, sans-serif",s.fillText(Ae(s,a.name,B-u-20),u,32),s.font="600 20px 'Courier New', Courier, monospace",s.fillStyle="#00c8ff",s.fillText(v(n),u,56),s.font="11px 'Courier New', Courier, monospace",s.fillStyle="#7a90aa";const m=[r?`24H ${v(r)}`:"",t?`ATH ${v(t)}`:""].filter(Boolean).join("  ");if(m&&s.fillText(m,u+2,72),l){const $=Me(e.trendCls),T=`${l.level.icon} ${q(l.pct)}`;s.font="11px 'Courier New', Courier, monospace";const c=s.measureText(T).width+14,i=B-c-12,x=12,E=20;s.fillStyle=$.bg,O(s,i,x,c,E,4),s.fill(),s.fillStyle=$.text,s.fillText(T,i+7,x+13)}const S=u,P=80,b=B-u-16,f=36;if(d.length>=2){const T=d.slice(-48).map(i=>i.current),c=pe(T,b,f);s.beginPath(),s.moveTo(S+c[0].x,P+c[0].y);for(let i=1;i<c.length;i++)s.lineTo(S+c[i].x,P+c[i].y);s.lineTo(S+c[c.length-1].x,P+f),s.lineTo(S+c[0].x,P+f),s.closePath(),s.fillStyle=Be(g,.08),s.fill(),s.beginPath(),s.moveTo(S+c[0].x,P+c[0].y);for(let i=1;i<c.length;i++)s.lineTo(S+c[i].x,P+c[i].y);s.strokeStyle=g,s.lineWidth=1.5,s.lineCap="round",s.lineJoin="round",s.stroke()}return s.font="10px system-ui, -apple-system, sans-serif",s.fillStyle="#3d5068",s.textAlign="right",s.fillText("SteamWatch · TREVISOFT",B-8,R-6),s.textAlign="left",new Promise(($,T)=>{h.toBlob(c=>c?$(c):T(new Error("Canvas toBlob returned null")),"image/png")})}function Ee(e){return new Promise((a,n)=>{const r=new Image;r.crossOrigin="anonymous",r.onload=()=>a(r),r.onerror=()=>n(new Error(`Image load failed: ${e}`)),r.src=e})}function O(e,a,n,r,t,l){e.beginPath(),e.moveTo(a+l,n),e.lineTo(a+r-l,n),e.quadraticCurveTo(a+r,n,a+r,n+l),e.lineTo(a+r,n+t-l),e.quadraticCurveTo(a+r,n+t,a+r-l,n+t),e.lineTo(a+l,n+t),e.quadraticCurveTo(a,n+t,a,n+t-l),e.lineTo(a,n+l),e.quadraticCurveTo(a,n,a+l,n),e.closePath()}function Ae(e,a,n){if(e.measureText(a).width<=n)return a;let r=a;for(;r.length>0&&e.measureText(r+"…").width>n;)r=r.slice(0,-1);return r+"…"}function Be(e,a){const n=e.replace("#",""),r=parseInt(n.slice(0,2),16),t=parseInt(n.slice(2,4),16),l=parseInt(n.slice(4,6),16);return`rgba(${r},${t},${l},${a})`}function Le(e){return["explosion","strong-up","up"].includes(e)?"#22c55e":["down","strong-down"].includes(e)?"#ef4444":e==="crash"?"#ff3366":"#1e3a5f"}function Me(e){return["explosion","strong-up","up"].includes(e)?{bg:"rgba(34,197,94,0.15)",text:"#22c55e"}:e==="crash"?{bg:"rgba(255,51,102,0.15)",text:"#ff3366"}:["down","strong-down"].includes(e)?{bg:"rgba(239,68,68,0.15)",text:"#ef4444"}:{bg:"rgba(100,116,139,0.15)",text:"#64748b"}}let j=!1;function Fe(e){return e instanceof Element&&!!e.closest(".share-bar, .btn-share")}function He(e=document){e.querySelectorAll(".share-bar").forEach(a=>{a.hidden=!0}),e.querySelectorAll(".btn-share.active").forEach(a=>{a.classList.remove("active")})}function Ge(e=document){j||(document.addEventListener("click",a=>{Fe(a.target)||He(e)}),j=!0)}const D=A("loading"),K=A("errorState"),qe=A("errorMessage"),M=A("gamesList"),X=A("emptyState"),N=A("fetchBar"),We=A("lastUpdated"),F=A("refreshBtn"),Re=A("settingsBtn"),_=document.getElementById("openOptionsBtn"),V=document.getElementById("retryBtn");let z=!1;async function W(){I("loading");try{const[e,a,n,r]=await Promise.all([ue(),he(),te(),ge()]);if(e.length===0){I("empty");return}const t=await Ce(e,a,me,n.purgeAfterDays);if(!z&&t.some(Ve)){z=!0;try{return await chrome.runtime.sendMessage({type:"FETCH_NOW"}),await W()}catch(l){console.error("[SteamWatch] Rich data hydration failed:",l)}}n.rankByPlayers&&t.sort((l,d)=>(d.current??0)-(l.current??0)),Ne(t,n.rankByPlayers,n.badgeFavoriteAppid),Je(r),Ze(t),I("list")}catch(e){console.error("[SteamWatch popup]",e),Qe("Failed to load data. Please try refreshing.")}}function Ne(e,a,n){if(M.innerHTML="",e.forEach((r,t)=>{const l=a&&e.length>1?["🥇","🥈","🥉"][t]??"":"",d=Ie(r,l,t===0&&a,n);if(M.appendChild(d),t<e.length-1){const g=document.createElement("li");g.className="game-divider",g.setAttribute("aria-hidden","true"),M.appendChild(g)}}),e.length>=5){const r=document.createElement("li");r.className="max-badge",r.setAttribute("role","status"),r.textContent="⚠ Max 5 games — remove one to add another",M.appendChild(r)}}function Ie(e,a,n,r){const{game:t,current:l,peak24h:d,allTimePeak:g,trendCls:h,displayTrendPct:s,displayTrendIcon:k,displayTrendCls:p,svgStr:y}=e,w=s!=null?`<span class="trend-badge ${o(p)}" aria-label="Trend ${o(q(s))}">${k?`${o(k)} `:""}${o(q(s))}</span>`:"",u=document.createElement("li");u.className="game-item";const m=document.createElement("div");m.className=`game-card ${o(h)}${n?" rank-first":""}`,m.dataset.appid=t.appid;const S=(t.name.match(/[A-Za-z0-9]/)??["?"])[0].toUpperCase(),P=fe(t.appid);m.innerHTML=`
    <div class="thumb-wrap" aria-hidden="true">
      <img
        class="game-thumb"
        src="${o(t.image)}"
        alt=""
        loading="lazy"
        width="56" height="42"
      >
      <div class="thumb-placeholder" style="--thumb-color:${P}" aria-hidden="true">
        ${o(S)}
      </div>
    </div>

    <div class="game-info">
      <div class="game-name" title="${o(t.name)}">
        ${a?`<span class="rank-badge" aria-hidden="true">${a}</span>`:""}
        <span class="game-name-text">${o(t.name)}</span>
      </div>
      <div class="game-stats">
        <span class="stat-current" aria-label="${v(l)} concurrent players">${v(l)}</span>
        <div class="stat-meta">
          <div class="stat-row">
            <span class="stat-label" aria-hidden="true">24H PK</span>
            <span class="stat-value" aria-label="24-hour peak">${v(d)}</span>
          </div>
          <div class="stat-row">
            <span class="stat-label" aria-hidden="true">ATH</span>
            <span class="stat-value" aria-label="all-time peak">${v(g)}</span>
          </div>
        </div>
        ${w}
      </div>
    </div>

    <div class="card-controls">
      <button class="btn-ctrl btn-share" aria-label="Share ${o(t.name)}" title="Share">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
          <path d="M8.59 13.51L15.42 17.49"/><path d="M15.41 6.51L8.59 10.49"/>
        </svg>
      </button>
      <button class="btn-ctrl btn-star${r===t.appid?" active":""}" aria-label="${r===t.appid?"Remove from badge":"Show on badge"}" title="Show on badge" aria-pressed="${String(r===t.appid)}">
        <svg viewBox="0 0 24 24" fill="${r===t.appid?"currentColor":"none"}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
        </svg>
      </button>
      <button class="btn-ctrl btn-expand" aria-expanded="false" aria-label="Expand details for ${o(t.name)}" title="Details">
        <svg class="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true">
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>
      <button class="btn-ctrl btn-remove" aria-label="Remove ${o(t.name)}" title="Remove">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>

    ${y?`
    <div class="card-bottom" aria-hidden="true">
      <div class="sparkline">${y}</div>
    </div>`:""}
  `;const b=document.createElement("div");b.className="card-panel",b.id=`panel-${t.appid}`,b.hidden=!0,b.setAttribute("aria-hidden","true"),b.setAttribute("aria-label",`Detailed stats for ${t.name}`);const f=document.createElement("div");f.className="share-bar",f.hidden=!0,f.setAttribute("aria-label","Share options"),f.innerHTML=`
    <button class="share-opt" data-share="text" aria-label="Copy text summary to clipboard">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
        <rect x="9" y="9" width="13" height="13" rx="2"/>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
      </svg>
      Copy text
    </button>
    <button class="share-opt" data-share="image" aria-label="Copy card image to clipboard">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
        <rect x="3" y="3" width="18" height="18" rx="2"/>
        <circle cx="8.5" cy="8.5" r="1.5"/>
        <polyline points="21 15 16 10 5 21"/>
      </svg>
      Copy image
    </button>
    <span class="share-feedback" role="status" aria-live="polite"></span>
  `,u.appendChild(m),u.appendChild(f),u.appendChild(b);const $=m.querySelector(".game-thumb"),T=m.querySelector(".thumb-wrap");be($,T,t.appid);const c=m.querySelector(".btn-expand"),i=m.querySelector(".btn-remove"),x=m.querySelector(".btn-share"),E=m.querySelector(".btn-star");return c.addEventListener("click",C=>{C.stopPropagation(),Oe(u,b,c,e)}),i.addEventListener("click",C=>{C.stopPropagation(),ze(t.appid)}),x.addEventListener("click",C=>{C.stopPropagation(),je(f,x)}),E.addEventListener("click",C=>{C.stopPropagation(),Ye(t.appid)}),f.querySelector("[data-share='text']").addEventListener("click",C=>{C.stopPropagation(),Ke(f,e)}),f.querySelector("[data-share='image']").addEventListener("click",C=>{C.stopPropagation(),Xe(f,e)}),u}function Oe(e,a,n,r){const t=a.hidden;a.hidden=!t,a.setAttribute("aria-hidden",String(!t)),n.setAttribute("aria-expanded",String(t)),e.classList.toggle("expanded",t),t&&!a.dataset.loaded&&(a.dataset.loaded="1",_e(a,r))}function _e(e,a){const{game:n,current:r,peak24h:t,allTimePeak:l,twitchViewers:d,avg24h:g,gain24h:h,retentionAvg:s,retentionGain:k,retentionDays:p,availableGraphWindows:y,defaultGraphWindow:w,discountPct:u,priceFormatted:m,priceOriginalFormatted:S}=a,P=d!=null?v(d):"—",b=g!=null?v(g):"—",f=h!=null?Y(h):"—",$=s!=null?v(s):"—",T=k!=null?Y(k):"—",c=y.length>0?`<div class="panel-window-selector" role="tablist" aria-label="Graph window selector">
        ${y.map(i=>`
          <button
            type="button"
            class="panel-window-btn${i.key===w?" active":""}"
            data-graph-window="${o(i.key)}"
            role="tab"
            aria-selected="${String(i.key===w)}"
          >${o(i.label)}</button>
        `).join("")}
      </div>`:"";e.innerHTML=`
    ${c}
    <div class="panel-sparkline" aria-hidden="true"></div>
    <dl class="panel-stats">
      <div class="panel-stat">
        <dt class="panel-stat-label">Current</dt>
        <dd class="panel-stat-value">${v(r)}</dd>
      </div>
      <div class="panel-stat">
        <dt class="panel-stat-label">24h peak</dt>
        <dd class="panel-stat-value">${v(t)}</dd>
      </div>
      <div class="panel-stat">
        <dt class="panel-stat-label">All-time peak</dt>
        <dd class="panel-stat-value">${v(l)}</dd>
      </div>
      <div class="panel-stat">
        <dt class="panel-stat-label">Twitch viewers</dt>
        <dd class="panel-stat-value">${o(P)}</dd>
      </div>
      <div class="panel-stat">
        <dt class="panel-stat-label">24h average</dt>
        <dd class="panel-stat-value">${o(b)}</dd>
      </div>
      <div class="panel-stat">
        <dt class="panel-stat-label">24h gain/loss</dt>
        <dd class="panel-stat-value">${o(f)}</dd>
      </div>
      <div class="panel-stat">
        <dt class="panel-stat-label">${o(`${p}d average`)}</dt>
        <dd class="panel-stat-value">${o($)}</dd>
      </div>
      <div class="panel-stat">
        <dt class="panel-stat-label">${o(`${p}d gain/loss`)}</dt>
        <dd class="panel-stat-value">${o(T)}</dd>
      </div>
    </dl>
    ${u!=null?`
    <div class="panel-sale-badge" aria-label="${o(`On sale: ${u}% off`)}">
      <span class="sale-pct">ON SALE −${o(String(u))}%</span>
      ${m?`<span class="sale-price">${o(m)}</span>`:""}
      ${S?`<s class="sale-orig">${o(S)}</s>`:""}
    </div>`:""}
    <div class="panel-links">
      <a class="panel-link" href="https://store.steampowered.com/app/${o(n.appid)}"
         target="_blank" rel="noopener noreferrer">Steam ↗</a>
      <a class="panel-link" href="https://steamdb.info/app/${o(n.appid)}"
         target="_blank" rel="noopener noreferrer">SteamDB ↗</a>
    </div>
  `,J(e,a,w),e.querySelectorAll("[data-graph-window]").forEach(i=>{i.addEventListener("click",()=>{const x=i.dataset.graphWindow;Ue(x)&&(e.querySelectorAll("[data-graph-window]").forEach(E=>{const C=E===i;E.classList.toggle("active",C),E.setAttribute("aria-selected",String(C))}),J(e,a,x))})})}function Ve(e){return e.current==null?!1:e.peak24h==null||e.allTimePeak==null||e.twitchViewers==null}function Y(e){const a=v(Math.abs(e));return e>0?`+${a}`:e<0?`-${a}`:"0"}function J(e,a,n){const r=e.querySelector(".panel-sparkline");if(!r)return;const t=n==null?null:a.availableGraphWindows.find(h=>h.key===n)??null,l=t?ke(a.snaps,t.windowMs):a.snaps,d=we(l,96),g=Q(d,{strokeColor:Z(d),width:372,height:56,maxPoints:96});r.innerHTML=g??"",r.hidden=!g}function Ue(e){return e==="24h"||e==="3d"||e==="retention"}function je(e,a){e.hidden?(e.hidden=!1,a.classList.add("active")):De(e,a)}function De(e,a){e.hidden=!0,a.classList.remove("active")}async function Ke(e,a){const n=e.querySelector(".share-feedback");try{await navigator.clipboard.writeText(Pe(a)),G(n,"✓ Copied!","success")}catch{G(n,"✗ Copy failed","error")}}async function Xe(e,a){const n=e.querySelector(".share-feedback"),r=e.querySelector("[data-share='image']");r.disabled=!0,G(n,"Rendering…","pending");try{const t=await xe(a);await navigator.clipboard.write([new ClipboardItem({"image/png":t})]),G(n,"✓ Image copied!","success")}catch{G(n,"✗ Copy failed","error")}finally{r.disabled=!1}}let U=null;function G(e,a,n){e.textContent=a,e.className=`share-feedback share-feedback--${n}`,U&&clearTimeout(U),n!=="pending"&&(U=setTimeout(()=>{e.textContent="",e.className="share-feedback"},2500))}async function ze(e){try{await ve(e),await W()}catch(a){console.error("[SteamWatch] Remove failed:",a)}}async function Ye(e,a){try{const t=(await te()).badgeFavoriteAppid===e?void 0:e;await ye({badgeFavoriteAppid:t}),document.querySelectorAll(".btn-star").forEach(l=>{const d=l.closest(".game-card"),h=(d==null?void 0:d.dataset.appid)===t;l.classList.toggle("active",h),l.setAttribute("aria-pressed",String(h)),l.setAttribute("aria-label",h?"Remove from badge":"Show on badge");const s=l.querySelector("polygon");s&&s.setAttribute("fill",h?"currentColor":"none")});try{await chrome.runtime.sendMessage({type:"FETCH_NOW"})}catch{}}catch(n){console.error("[SteamWatch] Toggle favorite failed:",n)}}function Je(e){if(e<=0){L(N);return}const a=Math.round((Date.now()-e)/6e4);let n;if(a<=0)n="Updated just now";else if(a===1)n="Updated 1 min ago";else if(a<60)n=`Updated ${a} min ago`;else{const r=new Date(e),t=r.getHours().toString().padStart(2,"0"),l=r.getMinutes().toString().padStart(2,"0");n=`Updated at ${t}:${l}`}N.textContent=n,H(N)}function Ze(e){const a=e.map(n=>n.fetchedAt).filter(n=>n>0);a.length&&(We.textContent=ee(Math.max(...a)))}function I(e){switch(L(D),L(K),L(M),L(X),L(N),e){case"loading":H(D);break;case"empty":H(X);break;case"list":H(M);break;case"error":H(K);break}}function Qe(e){qe.textContent=e,I("error")}F.addEventListener("click",async()=>{F.classList.add("spinning"),F.disabled=!0;try{await chrome.runtime.sendMessage({type:"FETCH_NOW"}),await W()}catch(e){console.error("[SteamWatch] Refresh failed:",e)}finally{F.classList.remove("spinning"),F.disabled=!1}});Re.addEventListener("click",()=>chrome.runtime.openOptionsPage());_==null||_.addEventListener("click",()=>chrome.runtime.openOptionsPage());V==null||V.addEventListener("click",()=>void W());Ge(document);W();
